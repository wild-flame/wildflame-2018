/**
 * Created by binarylu on 4/10/16.
 *
 * Rename this file to "config.js"
 */

var global_config = {
    client_id: "",
    client_secret: "",
    server_url: "",
    github_api: 'https://api.github.com',
    json_version: "1.0"
};